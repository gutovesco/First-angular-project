export default {
  jwt: {
    secret: 'ed9b45a5e141fe936cae2bbdd1ba6a34',
    expiresIn: '1d',
  },
};
